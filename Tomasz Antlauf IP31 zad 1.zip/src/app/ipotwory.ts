export interface IPotwory {
    id: number;
    nazwa: string;
    info: string;
    img: string;
}
